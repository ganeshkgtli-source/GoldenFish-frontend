
import { useState } from "react";
import {
  TrendingUp,
  Mail,
  User,
  Lock,
  Key,
  Check,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

interface Props {
  onSubmit: (data: any) => Promise<void>;
  onVerifyOtp?: (otp: string) => Promise<void>;
  loading: boolean;
}

export default function RegisterWizard({
  onSubmit,
  onVerifyOtp,
  loading,
}: Props) {
  const [step, setStep] = useState(1);

  const [form, setForm] = useState({
    username: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    client_id: "",
    api_key: "",
    api_secret: "",
    terms: false,
  });

  const [otp, setOtp] = useState("");
  const [showOtp, setShowOtp] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const steps = [
    { id: 1, title: "Personal Info", icon: User },
    { id: 2, title: "Security", icon: Lock },
    { id: 3, title: "API Setup", icon: Key },
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { name, value, checked, type } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? checked : value,
    }));
  };

  const validateStep = () => {
    setError("");

    if (step === 1) {
      if (
        !form.username ||
        !form.email ||
        !form.phone
      ) {
        setError("Please fill all personal details");
        return false;
      }

      if (!/\S+@\S+\.\S+/.test(form.email)) {
        setError("Please enter valid email");
        return false;
      }
    }

    if (step === 2) {
      if (
        !form.password ||
        !form.confirmPassword
      ) {
        setError("Fill all password fields");
        return false;
      }

      if (form.password.length < 8) {
        setError(
          "Password must be minimum 8 characters"
        );
        return false;
      }

      if (
        form.password !==
        form.confirmPassword
      ) {
        setError("Passwords do not match");
        return false;
      }
    }

    if (step === 3) {
      if (
        !form.client_id ||
        !form.api_key ||
        !form.api_secret
      ) {
        setError("Fill all API fields");
        return false;
      }

      if (!form.terms) {
        setError("Accept Terms & Conditions");
        return false;
      }
    }

    return true;
  };

  const next = () => {
    if (validateStep()) setStep(step + 1);
  };

  const back = () => {
    setError("");
    setStep(step - 1);
  };

  const submit = async () => {
    if (!validateStep()) return;

    try {
      setError("");
      setSuccess("");

      const payload = { ...form };
      delete payload.confirmPassword;

      await onSubmit(payload);

      setShowOtp(true);
      setSuccess("OTP sent to your email 📩");
    } catch (err: any) {
      setError(
        err?.response?.data?.detail ||
          "Registration failed"
      );
    }
  };

  const verifyOtp = async () => {
    if (!otp || otp.length < 6) {
      setError("Enter valid 6-digit OTP");
      return;
    }

    try {
      setError("");
      setSuccess("");

      if (onVerifyOtp) {
        await onVerifyOtp(otp);
      }

      setSuccess(
        "Email verified successfully ✅"
      );
    } catch (err: any) {
      setError(
        err?.response?.data?.detail ||
          "OTP verification failed"
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-red-600 shadow-lg shadow-red-500/30 flex items-center justify-center">
              <TrendingUp className="w-7 h-7 text-white" />
            </div>

            <div>
              <h1 className="text-4xl font-bold text-slate-900 dark:text-white">
                TimeLine
              </h1>
              <p className="text-sm text-slate-500">
                Investments Pvt Ltd
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
          {!showOtp ? (
            <>
              {/* Stepper */}
              <div className="px-10 py-8 border-b border-slate-200 dark:border-slate-800">
                <div className="relative flex justify-between">
                  <div className="absolute top-5 left-0 right-0 h-[2px] bg-slate-200 dark:bg-slate-700" />

                  <div
                    className="absolute top-5 left-0 h-[2px] bg-red-600 transition-all"
                    style={{
                      width:
                        step === 1
                          ? "0%"
                          : step === 2
                          ? "50%"
                          : "100%",
                    }}
                  />

                  {steps.map((s) => {
                    const Icon = s.icon;
                    const active = step >= s.id;

                    return (
                      <div
                        key={s.id}
                        className="relative z-10 flex flex-col items-center"
                      >
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            active
                              ? "bg-red-600 text-white"
                              : "bg-slate-200 dark:bg-slate-700 text-slate-500"
                          }`}
                        >
                          {step > s.id ? (
                            <Check className="w-5 h-5" />
                          ) : (
                            <Icon className="w-5 h-5" />
                          )}
                        </div>

                        <p className="mt-2 text-xs">
                          {s.title}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Alerts */}
              {(error || success) && (
                <div className="px-10 pt-6">
                  {error && (
                    <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm mb-3">
                      {error}
                    </div>
                  )}

                  {success && (
                    <div className="p-3 bg-green-50 text-green-600 rounded-lg text-sm">
                      {success}
                    </div>
                  )}
                </div>
              )}

              {/* Form */}
              <div className="p-10 space-y-5">
                {step === 1 && (
                  <>
                    <input
                      name="username"
                      placeholder="Username"
                      value={form.username}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                    <input
                      name="email"
                      placeholder="Email"
                      value={form.email}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                    <input
                      name="phone"
                      placeholder="Phone"
                      value={form.phone}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                  </>
                )}

                {step === 2 && (
                  <>
                    <input
                      name="password"
                      type="password"
                      placeholder="Password"
                      value={form.password}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                    <input
                      name="confirmPassword"
                      type="password"
                      placeholder="Confirm Password"
                      value={form.confirmPassword}
                      onChange={handleChange}
                      className="wizard-input"
                    />

                    {form.password && (
                      <div className="flex gap-1">
                        <div
                          className={`h-1 flex-1 rounded ${
                            form.password.length >= 8
                              ? "bg-green-500"
                              : "bg-slate-300"
                          }`}
                        />
                        <div
                          className={`h-1 flex-1 rounded ${
                            form.password.length >= 12
                              ? "bg-green-500"
                              : "bg-slate-300"
                          }`}
                        />
                        <div
                          className={`h-1 flex-1 rounded ${
                            /[A-Z]/.test(
                              form.password
                            ) &&
                            /[0-9]/.test(
                              form.password
                            )
                              ? "bg-green-500"
                              : "bg-slate-300"
                          }`}
                        />
                      </div>
                    )}
                  </>
                )}

                {step === 3 && (
                  <>
                    <input
                      name="client_id"
                      placeholder="Client ID"
                      value={form.client_id}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                    <input
                      name="api_key"
                      placeholder="API Key"
                      value={form.api_key}
                      onChange={handleChange}
                      className="wizard-input"
                    />
                    <input
                      name="api_secret"
                      placeholder="API Secret"
                      value={form.api_secret}
                      onChange={handleChange}
                      className="wizard-input"
                    />

                    <label className="flex gap-2 text-sm">
                      <input
                        type="checkbox"
                        name="terms"
                        checked={form.terms}
                        onChange={handleChange}
                      />
                      Accept Terms & Conditions
                    </label>
                  </>
                )}
              </div>

              {/* Footer */}
              <div className="px-10 py-6 bg-slate-50 dark:bg-slate-800/50 border-t flex justify-between">
                <button
                  onClick={back}
                  disabled={step === 1}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg disabled:opacity-50"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Back
                </button>

                {step < 3 ? (
                  <button
                    onClick={next}
                    className="wizard-primary-btn"
                  >
                    Next
                    <ChevronRight className="inline w-4 h-4 ml-1" />
                  </button>
                ) : (
                  <button
                    onClick={submit}
                    className="wizard-primary-btn"
                    disabled={loading}
                  >
                    {loading
                      ? "Processing..."
                      : "Register"}
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="p-10 text-center">
              <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-6">
                <Mail className="w-10 h-10 text-red-600" />
              </div>

              <h2 className="text-2xl font-bold mb-2">
                Verify Your Email
              </h2>

              <p className="text-slate-500 mb-6">
                Enter OTP sent to {form.email}
              </p>

              {error && (
                <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm mb-4">
                  {error}
                </div>
              )}

              {success && (
                <div className="p-3 bg-green-50 text-green-600 rounded-lg text-sm mb-4">
                  {success}
                </div>
              )}

              <input
                type="text"
                placeholder="000000"
                value={otp}
                onChange={(e) =>
                  setOtp(
                    e.target.value
                      .replace(/\D/g, "")
                      .slice(0, 6)
                  )
                }
                className="wizard-input text-center text-2xl tracking-widest mb-4"
              />

              <button
                onClick={verifyOtp}
                className="wizard-primary-btn w-full"
              >
                Verify OTP
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

