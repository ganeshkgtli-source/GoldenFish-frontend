import { z } from "zod";

export const registerSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  phone: z.string().min(10),
  password: z.string().min(6),
  client_id: z.string().min(1),
  api_key: z.string().min(1),
  api_secret: z.string().min(1),
  terms: z.boolean().refine(val => val === true, {
    message: "Accept Terms & Conditions",
  }),
});

export type RegisterFormData = z.infer<typeof registerSchema>;